library(ggplot)
library(ggpubr)

############################# FINAL STATS --------------------------------------

## DIFFERENTIAL GENE EXPRESSION ANALYSES 
# PER GENE BASIS USING abs LF
#PLOTS WITH RANK CORRELATIONS DO NOT FILTER FOR DN_CONT < 0
DEG_data <- read.table("DATA/DEG_DATA.txt")

### SPEARMAN RANK ANALYSIS ----
## DN
cor.test(abs(DEG_data$logFC), DEG_data$Dn_cont, method = 'spearman', exact = FALSE )
## DS
cor.test(abs(DEG_data$logFC), DEG_data$Ds_cont, method = 'spearman', exact = FALSE )

#GLM: SAME END RESULTS 
glm(abs(logFC) ~ Dn_cont, DEG_data, family = gaussian(link = 'log')) %>% 
  summary()

glm(abs(logFC) ~ Ds_cont, DEG_data, family = gaussian(link = 'log')) %>% 
  summary()

ggplot(DEG_data, aes(x = Dn_cont, y = abs(logFC))) + geom_point() + 
  geom_smooth(method = 'glm', method.args = list(family = gaussian(link = 'log'))) + stat_cor()
ggplot(DEG_data, aes(x = Ds_cont, y = abs(logFC))) + geom_point() + 
  geom_smooth(method = 'glm', method.args = list(family = gaussian(link = 'log'))) + stat_cor()


## ALLELE SPECIFIC EXPRESSION EXPRESSION ANALYSIS ----
#PER GENE BASIS USING abs LF
#PLOTS WITH RANK CORRELATIONS DO NOT FILTER FOR DN_CONT < 0
# REPORT MEASURES FOR HOM BIRDS and HET BIRDS
ASE_DATA <- read.table("DATA/ASE_DATA.txt")

#### SPEARMANS RANK FOR HETEROZYGOTES 
hetASE <- ASE_DATA[ASE_DATA$genotype == "AB",]
cor.test(abs(hetASE$log2_aFC), hetASE$Ds_cont, method = 'spearman', exact = FALSE)
cor.test(abs(hetASE$log2_aFC), hetASE$Dn_cont, method = 'spearman', exact = FALSE)

### SPEARMNS RANK FOR HOMOZYGOTES 
homASE <- ASE_DATA[ASE_DATA$genotype == "AA",]
cor.test(abs(homASE$log2_aFC), homASE$Ds_cont, method = 'spearman', exact = FALSE)
cor.test(abs(homASE$log2_aFC), homASE$Dn_cont, method = 'spearman', exact = FALSE)





